#include <stdlib.h>
#include <stdio.h>

int main(int argc, char const *argv[]){

    if( argc<3)
    {
        printf("No enough argument\n");
        return 0;
    }

    printf("%s\n",argv[0]);
    int size = atoi(argv[1]);

    char op = *argv[2];

    // Static Array
    //int arr[size];

    // Dynamic Array
    int *arr = (int *)malloc(size * sizeof(int));

    printf("Enter the elements\n");

    for (int i = 0; i < size; ++i)
    {
        scanf("%d",&arr[i]);
    }
    
    int result;

    if(op == '+')
    {
        result = 0;
        for (int i = 0; i < size; ++i)
        {
            result = result + arr[i];
        }
        
    }
    if(op == '-')
    {
        result = arr[0];
        for (int i = 1; i < size; ++i)
        {
            result = result - arr[i];
        }
        
    }
    else if(op == '*')
    {
        result = 1;
        for (int i = 0; i < size; ++i)
        {
            result = result * arr[i];
        }
        
    }
    else if(op == '/')
    {
        result = 1;
        for (int i = 0; i < size; ++i)
        {
            result = arr[i] / result;
        }
        
    }
    else{
        printf("Invalid Operator\n");
    }

    free(arr);

    printf("Result = %d\n", result);

    return 0;
}