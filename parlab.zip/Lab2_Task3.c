#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h> 

#define BUFFER_SIZE 5

int buffer[BUFFER_SIZE];
int buffer_count = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t buffer_not_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t buffer_not_empty = PTHREAD_COND_INITIALIZER;

void *producer(void *arg) {
    int part = *((int *)arg);
    free(arg);

    for (;;) {
        sleep(1); // Simulate part production time

        pthread_mutex_lock(&mutex);

        for (;;) {
            if (buffer_count < BUFFER_SIZE) { //check if not full
                buffer[buffer_count++] = part;
                printf("Producer %ld supplied part: %d\n", pthread_self(), part);
                pthread_cond_signal(&buffer_not_empty); //notify any waiting consumer threads that the buffer is not empty
                break;
            } else {
                pthread_cond_wait(&buffer_not_full, &mutex); // waiting for consumer thread before it can proceed to add more parts
            }
        }

        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

void *consumer(void *arg) {
    int id = *((int *)arg);
    free(arg);
    for (;;) {
        pthread_mutex_lock(&mutex);

        for (;;) {
            if (buffer_count > 0) {
                int car_parts[3] = {0};
                for (int i = 0; i < 3; i++) {
                    car_parts[i] = buffer[--buffer_count];
                }
                printf("Consumer %ld assembled a car with parts: %d, %d, %d\n", id, car_parts[0], car_parts[1], car_parts[2]);
                pthread_cond_signal(&buffer_not_full);
                break;
            } else {
                pthread_cond_wait(&buffer_not_empty, &mutex);
            }
        }

        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "numProducers numConsumers\n");
        return 1;
    }

    int num_producers = atoi(argv[1]);
    int num_consumers = atoi(argv[2]);

    pthread_t producer_threads[num_producers];
    pthread_t consumer_threads[num_consumers];

    srand(time(NULL));

    for (int i = 0; i < num_producers; i++) {
        int *part = malloc(sizeof(int));
        *part = rand() % 1000;
        pthread_create(&producer_threads[i], NULL, producer, part);
    }

    int thread_ids[num_consumers];
    for (int i = 0; i < num_consumers; i++) {
        thread_ids[i] = i+1;
        pthread_create(&consumer_threads[i], NULL, consumer,  &thread_ids[i]);
    }

    for (int i = 0; i < num_producers; i++) {
        pthread_join(producer_threads[i], NULL);
    }

    for (int i = 0; i < num_consumers; i++) {
        pthread_join(consumer_threads[i], NULL);
    }

    

    return 0;
}
