#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

int fib(int n) {
   int i, j;
   int fib_result;
   if (n<2)
      return n;
   else {
   #pragma omp parallel
   {
      #pragma omp single //only one thread should execute
      {
        fib_result=fib(n-1);
      }

      #pragma omp taskwait //ensure all the tasks by the parallel region have completed before proceeding
      {
      fib_result +=fib(n-2);
        }
   }  

   return fib_result;


   }
}


int main(int argc, char **argv){
   int n, result;
   char *a = argv[1];
   n = atoi(a);
   #pragma omp parallel
   {
      #pragma omp single
      result = fib(n);
   }
   printf("Result is %d\n", result);
}

