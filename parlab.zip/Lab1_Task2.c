#include <stdlib.h>
#include <stdio.h>

int main(int argc, char const *argv[]){


    int rows_M, cols_M,rows_N,cols_N;
 

    rows_M = atoi(argv[1]);
    cols_M = atoi(argv[2]);
    rows_N = atoi(argv[3]);
    cols_N = atoi(argv[4]);

    if(argc<5 || argc >5)
    {
        printf("Invalid args");
        return(-1);
    }

    if(rows_M != rows_N || cols_M != cols_N)
    {
        printf("Invalid size");
        return(-1);
    }

    int r,c;
    r= rows_M;
    c= cols_M;


    int **M,**N,**Result;

    M= (int **)malloc(r * sizeof(int));
    N= (int **)malloc(r * sizeof(int));
    Result = (int **)malloc(r * sizeof(int));


    for (int i = 0; i < c; i++)
    {
        M[i] = (int *)malloc(c * sizeof(int));
        N[i] = (int *)malloc(c * sizeof(int));
        Result[i] = (int *)malloc(c * sizeof(int));
    }

    
    
    printf("Enter Elements of M\n");
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            scanf("%d",&M[i][j]);
        }
        
    }

    printf("Enter Elements of N\n");
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            scanf("%d",&N[i][j]);
        }
        
    }
    
    //resultant
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            Result[i][j] = M[i][j] + N[i][j];
            printf("%d ",Result[i][j]);
            
        }
        printf("\n");
    }

    int diff= Result[0][0];
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            if(i == 0 && j == 0)
                continue;

            diff -= Result[i][j];
        }
        
    }

    printf("Difference = %d\n",diff);


    for (int i = 0; i < r; i++)
    {   
        free(M[i]);
        free(N[i]);
        free(Result[i]);
    }

    return 0;
}