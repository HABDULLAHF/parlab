#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <string.h>

int **matrix;
int matrix_size;
int num_threads;
int max_min_flag;
int result = 0;


void sequential_search() {
    int i, j;
    int value = matrix[0][0];

    for (i = 0; i < matrix_size; i++) {
        for (j = 0; j < matrix_size; j++) {
            if (max_min_flag == 1 && matrix[i][j] > value) {
                value = matrix[i][j];
            } else if (max_min_flag == 0 && matrix[i][j] < value) {
                value = matrix[i][j];
            }
        }
    }

    result = value;
}

void *threaded_search(void *arg) {
    clock_t start_time, end_time;

    int thread_id = *((int *)arg);
    int start = thread_id * (matrix_size / num_threads);
    int end = (thread_id == num_threads - 1) ? matrix_size : (thread_id + 1) * (matrix_size / num_threads);

    int local_result;
    start_time = clock();
    if (max_min_flag == 1) {
        local_result = matrix[start][0];
    } else {
        local_result = matrix[start][0];
    }
    
    for (int i = start; i < end; i++) {
        for (int j = 0; j < matrix_size; j++) {
            if (max_min_flag == 1 && matrix[i][j] > local_result) {
                local_result = matrix[i][j];
            } else if (max_min_flag == 0 && matrix[i][j] < local_result) {
                local_result = matrix[i][j];
            }
        }
    }


    if (max_min_flag == 1 && local_result > result) {
        result = local_result;
    } else if (max_min_flag == 0 && local_result < result) {
        result = local_result;
    }
    end_time = clock();
    printf("\nThread %d: Result is %d,Time taken by multithreaded search: %f seconds\n", thread_id, result,(double)(end_time - start_time) / CLOCKS_PER_SEC);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s <matrix_size> <num_threads> <max_min>\n", argv[0]);
        return 1;
    }

    matrix_size = atoi(argv[1]);
    num_threads = atoi(argv[2]);

    // flags of max min
    if (strcmp(argv[3], "max") == 0) {
        max_min_flag = 1; 
    } else if (strcmp(argv[3], "min") == 0) {
        max_min_flag = 0;
    } else {
        printf("Invalid choice for max_min. Use 'max' or 'min'.\n");
        return 1;
    }

    //matrix initialization
    matrix = (int **)malloc(matrix_size * sizeof(int *));
    for (int i = 0; i < matrix_size; i++) {
        matrix[i] = (int *)malloc(matrix_size * sizeof(int));
    }

    srand(time(NULL));
    for (int i = 0; i < matrix_size; i++) {
        for (int j = 0; j < matrix_size; j++) {
            matrix[i][j] = rand() % 100;
        }
    }

    clock_t start_time, end_time;

    // sequential
    start_time = clock();
    sequential_search();
    end_time = clock();

    printf("Sequential search: %s element is %d\n", (max_min_flag == 1) ? "Maximum" : "Minimum", result);
    printf("Time taken by sequential search: %f seconds\n", (double)(end_time - start_time) / CLOCKS_PER_SEC);

    result = (max_min_flag == 1) ? matrix[0][0] : matrix[0][0];


    // multithreaded
    pthread_t threads[num_threads];
    int thread_ids[num_threads];

    start_time = clock();

    for (int i = 0; i < num_threads; i++) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, threaded_search, &thread_ids[i]);
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    end_time = clock();

    // Free allocated memory
    for (int i = 0; i < matrix_size; i++) {
        free(matrix[i]);
    }
    free(matrix);

    return 0;
}
