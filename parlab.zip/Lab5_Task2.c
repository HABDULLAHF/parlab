#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<omp.h>

int *array;
int array_size;
int key;
int num_threads;

void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
 
void selectionSort(int arr[], int n)
{
    int i, j, min_idx;
 
    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;

        for (j = i+1; j < n; j++)
          if (arr[j] < arr[min_idx])
            min_idx = j;
 
        // Swap the found minimum element with the first element
           if(min_idx != i)
            swap(&arr[min_idx], &arr[i]);
    }
}

int binarySearch(int array[], int x, int low, int high) {
    if (high < low) {
        return -1;
    }

    int mid = low + (high - low) / 2;

    if (array[mid] == x) {
        return mid;
    }

    int left_result, right_result;

    #pragma omp task shared(array, x, low, mid, left_result)
    left_result = binarySearch(array, x, low, mid - 1);

    #pragma omp task shared(array, x, mid, high, right_result)
    right_result = binarySearch(array, x, mid + 1, high);

    #pragma omp taskwait

    if (left_result != -1) {
        return left_result;
    }

    return right_result;
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s array_size key num_threads\n", argv[0]);
        return 1;
    }

    array_size = atoi(argv[1]);
    key = atoi(argv[2]);
    num_threads = atoi(argv[3]);
    int index = 0;

    omp_set_num_threads(num_threads);

    array = (int *)malloc(array_size * sizeof(int));
    int a;

    srand(time(NULL));

    #pragma omp parallel for num_threads(num_threads)
    for (int i = 0; i < array_size; i++) {
        array[i] = rand() % array_size; 
    }
    omp_set_num_threads(num_threads);

    //sorting
    selectionSort(array, array_size);

    for (int i = 0; i < array_size; i++) {
        printf("%d ",array[i]);
    }

    printf("\n");
    index = binarySearch(array, key, 0, array_size - 1);

    if (index >= 0) {
        printf("binarySearch: Element %d found in index %d\n", key, index);
    } else {
        printf("binarySearch : Element %d not found\n", key);
    }

    free(array);

    return 0;
}
