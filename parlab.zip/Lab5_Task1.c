#include <stdlib.h>
#include <stdio.h>
#include<omp.h>

int main(int argc, char const *argv[]){


    int rows_M, cols_M,rows_N,cols_N,num_t;
    

    rows_M = atoi(argv[1]);
    cols_M = atoi(argv[2]);
    rows_N = atoi(argv[3]);
    cols_N = atoi(argv[4]);
    num_t = atoi(argv[5]);


    if(argc<6 || argc >6)
    {
        printf("Invalid args");
        return(-1);
    }

    if(rows_M != rows_N || cols_M != cols_N)
    {
        printf("Invalid size");
        return(-1);
    }

    int r,c;
    r= rows_M;
    c= cols_M;


    int **M,**N,**Result,**T_Result;
    int sum_Result = 0;
    int sum_Tras = 0;


    M= (int **)malloc(r * sizeof(int));
    N= (int **)malloc(r * sizeof(int));
    T_Result= (int **)malloc(r * sizeof(int));
    Result = (int **)malloc(r * sizeof(int));


    for (int i = 0; i < c; i++)
    {
        M[i] = (int *)malloc(c * sizeof(int));
        N[i] = (int *)malloc(c * sizeof(int));
        T_Result[i] = (int *)malloc(c * sizeof(int));
        Result[i] = (int *)malloc(c * sizeof(int));

    }

    printf("Enter Elements of M\n");
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            scanf("%d",&M[i][j]);
        }
        
    }

    printf("Enter Elements of N\n");
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            scanf("%d",&N[i][j]);
        }
        
    }

    omp_set_num_threads(num_t); //set num threads
    #pragma omp parallel
    {    

        //Multiplication
        #pragma omp for
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                Result[i][j] = 0;
                for (int k = 0; k < c; k++) {
                    Result[i][j] += M[i][k] * N[k][j];
                    
                }
            }

        }

        //transpose
        #pragma omp for
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                T_Result[i][j] = Result[j][i];
            }
        }
  
        //Sum
        #pragma omp single
        for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                #pragma omp task shared(sum_Result)
                sum_Result = sum_Result + Result[i][j];

                #pragma omp task shared(sum_Tras)
                sum_Tras = sum_Tras + T_Result[i][j];
            }
            printf("\n");
        }

    }

    /*
    //display matrix mul
    // Matrix multiplication
    printf("Matrix Multiplication Result:\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < r; j++) {
            printf("%d ", Result[i][j]);    
        }
        printf("\n");
    } 
            //transpose print
            for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                printf("%d ",T_Result[i][j]);
                
            }
            printf("\n");
        }

    */
        // Matrix multiplication
        printf("Matrix Multiplication Result:\n");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                printf("%d ", Result[i][j]);    
            }
            printf("\n");
        } 

        //transpose print
        printf("Matrix Transpose Result:\n");
        for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                printf("%d ",T_Result[i][j]);
                
            }
            printf("\n");
        }

    printf("Matrix sum = %d \nTranspose Sum = %d \n",sum_Result,sum_Tras);

    if(sum_Result==sum_Tras)
    {
        printf("Same sum\n");
    }
    else{
        printf("Not Same\n");
    }


    for (int i = 0; i < r; i++)
    {   
        free(M[i]);
        free(N[i]);
        free(Result[i]);
        free(T_Result[i]);

    }

    return 0;
}