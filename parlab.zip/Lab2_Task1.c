#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

int *array;
int array_size;
int key;
int num_threads;
int found = 0;

void sequential_search() {
    for (int i = 0; i < array_size; i++) {
        if (array[i] == key) {
            found = 1;
            printf("\nKey index : %d\n", i);
            break;
        }
    }
}

void *threaded_search(void *arg) {
    clock_t start_time, end_time;

    
    int thread_id = *((int *)arg);
    int chunkSize = array_size / num_threads;
    int start = thread_id * chunkSize;
    int end = (thread_id == num_threads - 1) ? array_size : (thread_id + 1) * chunkSize;

    
    for (int i = start; i < end; i++) {
        if (array[i] == key) {
            start_time = clock();
            found = 1;
            printf("\nKey index : %d, id : %d\n", i,thread_id);
            end_time = clock();
            break;
        }
    }
    if (found) {
        printf("Time taken by multithreaded search: %f seconds , ID : %d \n", (double)(end_time - start_time) / CLOCKS_PER_SEC, thread_id);
    } else {
        printf("Multithreaded search: Element %d not found\n", key);
    }

    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s array_size key num_threads\n", argv[0]);
        return 1;
    }

    array_size = atoi(argv[1]);
    key = atoi(argv[2]);
    num_threads = atoi(argv[3]);

    array = (int *)malloc(array_size * sizeof(int));

    srand(time(NULL));
    for (int i = 0; i < array_size; i++) {
        array[i] = rand() % 100; 
    }

    clock_t start_time, end_time;

    start_time = clock();
    sequential_search();
    end_time = clock();

    if (found) {
        printf("Sequential search: Element %d found\n", key);
    } else {
        printf("Sequential search: Element %d not found\n", key);
    }

    printf("Time taken by sequential search: %f seconds\n", (double)(end_time - start_time) / CLOCKS_PER_SEC);

    found = 0;

    pthread_t threads[num_threads];
    int thread_ids[num_threads];

    start_time = clock();

    for (int i = 0; i < num_threads; i++) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, threaded_search, &thread_ids[i]);
    }


    end_time = clock();

    free(array);

    return 0;
}
